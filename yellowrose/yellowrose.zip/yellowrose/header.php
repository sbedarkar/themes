<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
    <title>The Yellow Rose - Strong Oak Society </title>
    <?php wp_head(); ?>

  </head>
  <body >
  <div class="overlay">
  <nav class="navbar navbar-inverse  bg-img  ">
                
                  <div class="container-fluid">
                    <div class="navbar-header">
                      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>                        
                      </button>
                      <a class="navbar-brand w3-hide-large" href="#"></a>
                    </div>
                    <div class="collapse navbar-collapse" id="myNavbar">
                      <?php
                		wp_nav_menu( array(
                			'theme_location'    => 'primary',
                			'menu_class'        => 'nav navbar-nav'
              
                		) );
                	 ?>
                    </div>
                  </div>
                </nav>
  </div>
  <?php echo do_shortcode('[metaslider id="231"]'); ?>
<div id="myCarousel" class="carousel slide">

</div>

        
 
