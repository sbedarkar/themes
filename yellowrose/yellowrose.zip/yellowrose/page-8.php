<?php get_header(); ?>

<div class="container">
	<div class="row">
        <div class="col-xs-12 col-sm-6">
        	<h3><?php the_title(); ?></h3>
		
			<p><?php the_content(); ?></p>
        </div>
		 <div class="col-xs-12 col-sm-6 ">
		 	<h1>image</h1>
		 </div>
</div>
</div>
<?php 
get_footer(); 
?>