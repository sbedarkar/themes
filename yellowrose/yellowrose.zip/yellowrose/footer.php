<!-- Footer -->
 </header><!-- .header -->
</div> <!--col-sx-12 -->
</div><!--row -->
<div class="row">
<footer >


  <div class="container-fluid"style="margin-right: -15px; margin-left: -15px; ">
  <div class="media-icon-continer">
    <div class="row">
      <div class="col-xs-12 col-sm-4">
           <p>www.alignable.com</p>
        <iframe src="https://www.alignable.com/marietta-ga/rose-marje-creations-communications" width="340" height="70" style="border:none;overflow:hidden"></iframe>
        <!--<button>Donate</button>-->
      </div>
      <div class="col-xs-12 col-sm-4">
        <p>Margaret Edinburgh</p>
        <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Frosemarje%2F&tabs=timeline&width=340&height=70&small_header=true&adapt_container_width=true&hide_cover=true&show_facepile=true&appId=1981144111971708" width="340" height="70" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
      </div>
      <div class="col-xs-12 col-sm-4">
        <p>Find Us Online</p>
<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FThe-Yellow-Rose-Strong-Oak-Society-162948280468670%2F%3Fepa%3DSEARCH_BOX%26jazoest%3D265100120975799505554110838756868175748872551229987100957856105751216665106495168871027567735411553458158651001217511199118119796990116786649109687910545691218490106758195728512089521125711311998771004983511098381&tabs=timeline&width=340&height=70&small_header=true&adapt_container_width=true&hide_cover=true&show_facepile=true&appId" width="340" height="70" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
          <!--<a href="#" class="fa fa-facebook"></a>-->
          <!--<a href="#" class="fa fa-twitter"></a>-->
          <!--<a href="https://www.instagram.com/kzelmanrd/?hl=en" class="fa fa-instagram"></a>-->
      </div>  
    </div> <!-- .row -->
    
    </div><!-- .media-icon-continer-->
</div>
</footer>
</div>
<?php wp_footer(); ?>
</body>
</html>