<!--<div class="container">-->
	
	
	<p class="Tangerine-Font"><?php the_content(); ?></p>
	
	<!--<hr>-->
<!--</div>-->