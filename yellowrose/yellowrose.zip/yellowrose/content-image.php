
  <img class=" thumbnail-img" src=<?php the_post_thumbnail(); ?>
     
 