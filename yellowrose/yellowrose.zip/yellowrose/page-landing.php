 
 <?php 
	
/*
	Template Name: Slider-Navbar
*/
	
get_header(); ?>

 
<div class="header-container text-center" >

  <div class="w3-display-bottomleft" style="padding:24px 48px">
      <h1 class="w3-center w3-jumbo Tangerine-Font overlay-text">The Yellow Rose - Strong Oak Society</h1>
  <p class="w3-center w3-xxlarge Gamja-Flower-Font overlay-text">Honoring our seniors and celebrating their life’s milestone!</p>

  </div>
</div>

<!-- About Section -->
<div class="w3-container"  id="about">
  <h3 class="w3-center w3-xxlarge Tangerine-Font overlay-text-hide">The Yellow Rose - Strong Oak Society</h3>
  <!--<p class="w3-center w3-xxlarge Tangerine-Font overlay-text-hide">Honoring our seniors and celebrating their life’s milestone!</p>-->
  <div class="w3-row-padding w3-center" style="margin-top:64px">
    
    <div class="w3-third">
       <p class="w3-xxlarge Gamja-Flower-Font">Our Mission</p>
      <img src="https://yellowrosestrongoaksociety.com/wp-content/uploads/2018/12/rawpixel-250087-unsplash.jpg" alt="Mission" style="width:150px; border-radius: 50%; ">
      
      
      <p class=" w3-large Noto-Serif-TC-font"  ><?php 
	

	$lastBlog = new WP_Query('type=post&posts_per_page=-1&category_name=Mission');
			
		if( $lastBlog->have_posts() ):
			
			while( $lastBlog->have_posts() ): $lastBlog->the_post(); ?>
				
				<?php get_template_part('content',get_post_format()); ?>
			
			<?php endwhile;
			
		endif;
		
		wp_reset_postdata();

			
	?></p>

    </div>
    <div class="w3-third">
        <img src="https://yellowrosestrongoaksociety.com/wp-content/uploads/2018/12/celebration.jpg" alt="Mission" style="width:150px; border-radius: 50%;">
     
      <p class="w3-large">Activities</p>
      <p><?php 
	

	$lastBlog = new WP_Query('type=post&posts_per_page=-1&category_name=ACTIVITIES');
			
		if( $lastBlog->have_posts() ):
			
			while( $lastBlog->have_posts() ): $lastBlog->the_post(); ?>
				
				<?php get_template_part('content',get_post_format()); ?>
			
			<?php endwhile;
			
		endif;
		
		wp_reset_postdata();

			
	?></p>
    </div>
    <div class="w3-third">
       <img src="https://yellowrosestrongoaksociety.com/wp-content/uploads/2018/12/support.jpg" alt="Mission" style="width:150px; border-radius: 50%; ">
      <p class="w3-large">Support</p>
      <p><?php 
	

	 $lastBlog = new WP_Query('type=post&posts_per_page=-1&category_name=Support');
			
		if( $lastBlog->have_posts() ):
			
			while( $lastBlog->have_posts() ): $lastBlog->the_post(); ?>
				
				<?php get_template_part('content',get_post_format()); ?>
			
			<?php endwhile;
			
		endif;
		
		wp_reset_postdata();

			
	?></p>
    </div>
  </div>
</div>

<?php get_footer(); ?>