<?php 
	
/*
	Template Name: CV
*/
	
get_header(); ?>

<!-- Container (About Section) -->
<div class="w3-content w3-container w3-padding-64" id="about">
  <h3 class="w3-center">ABOUT ME</h3>
  <p class="w3-center"><em>I love storytelling</em></p>
  <p>Margaret Edinburgh holds a Bachelor of Arts in Office Administration from Indiana State University. Her storytelling name is Margaret Rose. She has worked in a number of companies, as well as Indiana State University. 
  She has completed certification as a Distinguished Toastmaster and been the sponsor, mentor, or both of several new Toastmasters Clubs – including three at IBM. For the majority of her career with the IBM, Margaret worked 
  as the Assistant to scores of executives, first line managers, and staff in several areas of the business. After more than 28 years, she retired.</p>
  <div class="w3-row">
      
    <div class="w3-col m4 w3-center w3-padding-large">
      <p><b><i class="fa fa-user w3-margin-right"></i>Margaret Edinburgh</b></p><br>
      <img src="https://yellowrosestrongoaksociety.com/wp-content/uploads/2018/12/New-Margaret-Edindurgh.jpg" class="w3-round w3-image " alt="Photo of Me" width="100" height="133">
    </div>

    <!-- Hide this text on small devices -->
    <div class="w3-col m6 w3-hide-small w3-padding-large">
      <p>Since retiring, Margaret is on an earnest journey of self-discovery. As she delves deeper and deeper into her personal quest, she has dubbed herself a “Sampler of Life.” Although Margaret also considers herself a Toastmasters junkie, 
      she is exploring storytelling, clowning, writing, crafting, and teaching. Her “Order of NZingah Doll Collection” has taken her to two continents – Europe and Africa. She has released two storytelling CDs titled, 
      “The Order of NZingah Doll Collection: Women of Dignity,” and “I Done Tole Y’all.” She has exhibited her dolls around the country, including a one woman show in Atlanta’s Auburn Avenue African American Research Library, 
      the APEX Museum, and a city-wide tea party at the Vigo County Historical Museum in Terre Haute, IN. She has told stories in such venues such as Kuumba Storytellers of Georgia’s Mama Tales, as well as in nursing homes,
      assisted living facilities, and senior centers. Recently, Margaret has taught a beginning storytelling class at Cobb County’s E.L.M. program for those who are 50+. Because of her volunteerism, Margaret has received numerous awards. 
      A firm believer that stories are a great way to preserve her African-American history and heritage, she is especially fond of stories that have a moral, educational value, humor or all of the above.</p>
    </div>
  </div>
  
</div>




<!-- Container (Portfolio Section) -->
<div class="w3-content w3-container w3-padding-64" id="portfolio">
  <h3 class="w3-center">MY WORK</h3>
  <p class="w3-center"><em>Here are some of my latest lorem work ipsum tipsum.<br> Click on the images to make them bigger</em></p><br>

  <!-- Responsive Grid. Four columns on tablets, laptops and desktops. Will stack on mobile devices/small screens (100% width) -->
  <div class="w3-row-padding w3-center">
    <div class="w3-col m3">
      <img src="https://yellowrosestrongoaksociety.com/wp-content/uploads/2018/12/yellowrose9-1.jpg" style="width:100%" alt="The mist over the mountains">
    </div>

    <div class="w3-col m3">
      <img src="https://yellowrosestrongoaksociety.com/wp-content/uploads/2018/12/yellowrose13-1.jpg" style="width:100%"  alt="Coffee beans">
    </div>

    <div class="w3-col m3">
      <img src="https://yellowrosestrongoaksociety.com/wp-content/uploads/2018/12/yellowrose9-1.jpg" style="width:100%"  alt="Bear closeup">
    </div>

    <div class="w3-col m3">
      <img src="https://yellowrosestrongoaksociety.com/wp-content/uploads/2018/12/yellowrose13-1.jpg" style="width:100%"  alt="Quiet ocean">
    </div>
  </div>

  <div class="w3-row-padding w3-center w3-section w3-hide-small">
    <div class="w3-col m3">
      <img src="https://yellowrosestrongoaksociety.com/wp-content/uploads/2018/12/yellowrose13-1.jpg" style="width:100%"  alt="The mist">
    </div>

    <div class="w3-col m3">
      <img src="https://yellowrosestrongoaksociety.com/wp-content/uploads/2018/12/yellowrose9-1.jpg" style="width:100%"  alt="My beloved typewriter">
    </div>

    <div class="w3-col m3">
      <img src="https://yellowrosestrongoaksociety.com/wp-content/uploads/2018/12/yellowrose13-1.jpg" style="width:100%"  alt="Empty ghost train">
    </div>

    <div class="w3-col m3">
      <img src="https://yellowrosestrongoaksociety.com/wp-content/uploads/2018/12/yellowrose9-1.jpg" style="width:100%"  alt="Sailing">
    </div>
   
  </div>
</div>

<!-- Modal for full size images on click-->
<div id="modal01" class="w3-modal w3-black" onclick="this.style.display='none'">
  <span class="w3-button w3-large w3-black w3-display-topright" title="Close Modal Image"><i class="fa fa-remove"></i></span>
  <div class="w3-modal-content w3-animate-zoom w3-center w3-transparent w3-padding-64">
    <img id="img01" class="w3-image">
    <p id="caption" class="w3-opacity w3-large"></p>
  </div>
</div>

<!-- Third Parallax Image with Portfolio Text -->
<div class="bgimg-3 w3-display-container w3-opacity-min">
  <div class="w3-display-middle">
     <span class="w3-xxlarge w3-text-white w3-wide">CONTACT</span>
  </div>
</div>

<!-- Container (Contact Section) -->
<div class="w3-content w3-container w3-padding-64" id="contact">
  <h3 class="w3-center">Swing by for a cup of <i class="fa fa-coffee"></i>, or leave me a note:<</h3>
  <p class="w3-center"><em>I'd love your feedback!</em></p>

  <div class="w3-row w3-padding-32 w3-section">
    <div class="w3-col m6 w3-container">
      <img src="https://yellowrosestrongoaksociety.com/wp-content/uploads/2018/12/map.jpg" class="w3-image w3-round" style="width:100%">
      <div class="w3-large w3-margin-bottom">
        <p><i class="fa fa-map-marker fa-fw w3-hover-text-black w3-xlarge w3-margin-right"></i>Kennesaw, GA<br> </p>
        <i class="fa fa-phone fa-fw w3-hover-text-black w3-xlarge w3-margin-right"></i> Phone: 770 425 3161<br>
        <i class="fa fa-envelope fa-fw w3-hover-text-black w3-xlarge w3-margin-right"></i>cobbstoriesmre@gmail.com<br>
      </div>
    </div>
    <div class="w3-col m6 w3-panel">
      
      
      <?php 
	
	if( have_posts() ):
		
		while( have_posts() ): the_post(); ?>
		
			<p><?php the_content(); ?></p>
			
			<hr>
		
		<?php endwhile;
		
	endif;
			
	?>
    </div>
  </div>
</div>

<?php get_footer(); ?>
